<div class="card text-center">
  <div class="card-body">
    <h3 class="card-title text-danger">Seu carrinho está vazio!</h3>
    <h5 class="card-text">Visite nossa loja abaixo e escolha seus produtos favoritos.</h5><br>
    <a href="#" class="btn btn-primary">Ir para Produtos</a>
  </div>
  <div class="card-footer text-body-secondary">
    &nbsp;
  </div>
</div>