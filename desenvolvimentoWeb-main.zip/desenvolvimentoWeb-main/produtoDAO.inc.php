<?php
    include_once "conexao.inc.php";
        
    class produtoDAO{
        private $con;

    public function incluirProduto(Produto $produto){
        
           $sql =  $this->con->prepare("insert into produtos(nome,data_fab,preco,estoque,descricao,resumo,referencia,cod_fab) values(:nome,:data_fab,:preco,:estoque,:descricao,:resumo,:referencia,:cod_fab)");             

           $sql->bindValue( ':nome',$produto->getNome());
           $sql->bindValue( ':data_fab',$produto->getData_fab());
           $sql->bindValue( ':preco',$produto->getPreco());
           $sql->bindValue( ':estoque',$produto->getEstoque());
           $sql->bindValue( ':descricao',$produto->getDescricao());
           $sql->bindValue( ':resumo',$produto->getResumo());
           $sql->bindValue( ':referencia',$produto->getReferencia());
           $sql->bindValue( ':cod_fab',$produto->getCodFab());
           
           $sql->execute();        
    }

    public function excluirProduto($id){


    }
    public function alterarProduto(Produto $produto){


    }

    public function getProduto($id){

    }


    public function getProdutos(){

    }
}


?>