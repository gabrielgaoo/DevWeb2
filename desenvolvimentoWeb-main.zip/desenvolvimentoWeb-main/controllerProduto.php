<?php

    $opcao = $_REQUEST['opcao'];

    if($opcao == 1){
            

    }

?>